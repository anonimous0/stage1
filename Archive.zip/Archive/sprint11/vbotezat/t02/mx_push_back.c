#include "list.h"

void mx_push_back(t_list **list, void *data) {
    t_list * now = *list;

    while (now -> next != NULL)
        now = now -> next;


    now -> next = (t_list *) malloc(sizeof(t_list));
    now -> next -> data = data;
    now -> next -> next = NULL;
}
