#include "list.h"
void mx_pop_back(t_list **list) {

    if ((*list) -> next == NULL) {
        free(list);
        *list = NULL;
    }

    t_list *now = *list;
    while (now -> next -> next != NULL) {
        now = now -> next;
    }

    free(now -> next);
    now -> next = NULL;
}
