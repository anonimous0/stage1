#include "create_new_agents.h"

t_agent **mx_create_new_agents(char **name, int *power, int *strength, int count) {
    for (int i = 0; i < count; i++) {
        if (name[i] == 0 || power[i] == 0 || strength[i] == 0 || count == 0) {
            return NULL;
        }
    }
    printf("%s\n", "tr");
    int letersA = 0;
    for (int i = 0; i < count; i++)
        letersA += mx_strlen(name[i]);
    int letersB;

    t_agent **new_agents = (t_agent **)malloc(8 * count + letersA);
    for (int i = 0; i < count; i++) {
        letersB = 0;
        letersB = mx_strlen(name[i]);
        new_agents[i] = (t_agent *)malloc(8 + letersB);
    }
    for (int i = 0; i < count; i++) {
        new_agents[i]->name = mx_strdup(name[i]);
        new_agents[i]->power = power[i];
        new_agents[i]->strength = strength[i];
    }
    new_agents[count] = NULL;

    return new_agents;
}
