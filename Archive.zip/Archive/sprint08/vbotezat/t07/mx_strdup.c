#include "create_new_agents.h"

char *mx_strdup(const char *str) {
    char *str_cop = mx_strnew(mx_strlen(str));
    mx_strcpy(str_cop, str);
    return str_cop;
}
