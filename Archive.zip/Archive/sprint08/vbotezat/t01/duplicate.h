#ifndef DUPLICATE_H
#deine DUPLICATE_H

#include <stdlib.h>
#include <stdio.h>

typedef struct s_intarr
{
    int *arr;
    int size;
} t_intarr;
#endif
