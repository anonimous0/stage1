#include "hex_to_nbr.h"

unsigned long mx_hex_to_nbr(const char *hex) {
    if (!hex)
        return 0;
    int len = 0;
    unsigned long num = 0;
    unsigned long st = 1;
    while (hex[len])
        len++;
        for (int i = len - 1; i >= 0; i--) {

            if (mx_isdigit(hex[i]))
            {
                num += (hex[i] - 48)* st;

                st = st * 16;
            }


            else if (mx_isupper(hex[i]))
            {
                num += (hex[i] - 55) * st;

                st = st * 16;
            }
            else if (mx_islower(hex[i]))
            {
                num += (hex[i] - 87) * st;

                st = st * 16;
            }
        }

    return num;
}
