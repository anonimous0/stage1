#ifndef NBR_TO_HEX_H
#define NBR_TO_HEX_H

#include <stdio.h>
#include <stdlib.h>

char *mx_nbr_to_hex(unsigned long nbr);

char *mx_strnew(const int size);

#endif
