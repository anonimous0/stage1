#ifndef CALC_H
#define CALC_H

#include <stdbool.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

char *mx_strncpy(char *dst, const char *src, int len);

void mx_print_equat(int num1, const char *s, int num2, int num3);

int mx_strt_of_q_mrk(char *str);

void mx_crypto_bol(char **argv);

int q_count(char *s);

void mx_printchar(char c);

void mx_strdel(char **str);

char *mx_strnew(const int size);

char *mx_strtrim(const char *str);

int mx_atoi(const char *str);

bool mx_isdigit(int c);

bool mx_isspace(int c);

void mx_printint(int num);

void mx_printstr(const char *s);

int mx_strcmp(const char *s1, const char *s2);

char *mx_strcpy(char *dst, const char *src);

int mx_strlen(const char *s);

int mx_q_to_num(char *s);

char mx_sign(char *s);

#endif
