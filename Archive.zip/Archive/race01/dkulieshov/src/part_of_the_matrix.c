#include "../inc/calc.h"

int main(int argc, char **argv) {
    if (argc == 0)
        return 1;
    mx_crypto_bol(argv);
    return 0;

}
