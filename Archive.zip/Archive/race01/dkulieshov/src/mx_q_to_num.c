#include "../inc/calc.h"

int mx_q_to_num(char *s) {
    int i = 0;
    int counter = 0;
    int res = 1;

    while(s[i]) {
        if(s[i] == '?')
            counter++;
        i++;
    }

    if(counter == 1)
        return 0;

    for (int j = 1; j < counter; j++)
        res *= 10;

    return res;
}
