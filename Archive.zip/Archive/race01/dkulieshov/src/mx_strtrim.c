#include "../inc/calc.h"

char *mx_strtrim(const char *str) {
    int a = 0;
    int b = mx_strlen(str) - 1;

    while (mx_isspace(str[a])) {
        a++;
    }
    while (mx_isspace(str[b])) {
        b--;
    }
    char *istr = mx_strnew(b);

    istr = mx_strncpy(istr, &str[a], b - a + 1);
    //DEBUG_ONLY( printf("%s\n", istr);)
    return istr;

}
