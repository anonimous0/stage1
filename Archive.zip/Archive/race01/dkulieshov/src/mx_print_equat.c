#include "../inc/calc.h"

void mx_print_equat(int num1, const char *s, int num2, int num3) {
    mx_printint(num1);
    mx_printchar(' ');
    mx_printstr(s);
    mx_printchar(' ');
    mx_printint(num2);
    mx_printchar(' ');
    mx_printchar('=');
    mx_printchar(' ');
    mx_printint(num3);
    mx_printchar('\n');
}
