#include "../inc/calc.h"

void mx_crypto_bol(char **argv) {


    int num1;
    int num2;
    int num3;

    int q_num1 = 0;
    int q_num2 = 0;
    int q_num3 = 0;

    int s_num1 = mx_strt_of_q_mrk(mx_strtrim(argv[1]));
    int e_num1 = mx_strt_of_q_mrk(mx_strtrim(argv[1])) * 10;
    int s_num2 = mx_strt_of_q_mrk(mx_strtrim(argv[3]));
    int e_num2 = mx_strt_of_q_mrk(mx_strtrim(argv[3])) * 10;
    int s_num3 = mx_strt_of_q_mrk(mx_strtrim(argv[4]));
    int e_num3 = mx_strt_of_q_mrk(mx_strtrim(argv[4])) * 10;

    if (s_num1 == 1) {
        s_num1--;
    }
    if (s_num2 == 1) {
        s_num2--;
    }
    if (s_num3 == 1) {
        s_num3--;
    }

    if (mx_atoi(mx_strtrim(argv[1])))
        num1 = mx_atoi(mx_strtrim(argv[1]));
    else {
        num1 = mx_q_to_num(mx_strtrim(argv[1]));
        q_num1++;
    }

    if (mx_atoi(mx_strtrim(argv[3])))
        num2 = mx_atoi(mx_strtrim(argv[3]));
    else {
        num2 = mx_q_to_num(mx_strtrim(argv[3]));
        q_num2++;
    }

    if (mx_atoi(mx_strtrim(argv[4])))
        num3 = mx_atoi(mx_strtrim(argv[4]));
    else {
        q_num3++;
        num3 = mx_q_to_num(mx_strtrim(argv[4]));
    }

    if (q_num1 > 0 && q_num2 == 0 && q_num3 == 0){
        for(int i = s_num1; i < e_num1; i++) {
                if (mx_strcmp(mx_strtrim(argv[2]),"+") == 0) {
                    if (num1 + num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num1++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0) {
                    if (num1 - num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num1++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                    if (num1 * num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num1++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "/") == 0) {
                    if (num1 / num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num1++;
                }
        }
    }
    else if (q_num2 > 0 && q_num1 == 0 && q_num3 == 0) {
        for(int i = s_num2; i < e_num2; i++) {
                if (mx_strcmp(mx_strtrim(argv[2]), "+") == 0) {
                    if (num1 + num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0){
                    if (num1 - num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                    if (num1 * num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]),"/") == 0) {
                    if (num1 / num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
            }
        }
    else if (q_num3 > 0 && q_num2 == 0 && q_num1 == 0){
        for(int i = s_num3; i < e_num3; i++) {
                if (mx_strcmp(mx_strtrim(argv[2]), "+") == 0) {
                    if (num1 + num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num3++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0){
                    if (num1 - num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num3++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                    if (num1 * num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num3++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]),"/") == 0) {
                    if (num1 / num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num3++;
                }
            }
    }
    else if (q_num2 > 0 && q_num3 > 0 && q_num1 == 0){
        while (num3 >= s_num3 && num3 < e_num3) {
            num2 = mx_q_to_num(mx_strtrim(argv[3]));
            if (mx_strcmp(mx_strtrim(argv[2]), "+") == 0) {
                while (num2 >= s_num2 && num2 < e_num2) {
                    if (num1 + num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                num3++;
            }
            else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0){
                while (num2 >= s_num2 && num2 < e_num2) {
                    if (num1 - num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                num3++;
            }
            else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                while (num2 >= s_num2 && num2 < e_num2) {
                    if (num1 * num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                num3++;
            }
            else if (mx_strcmp(mx_strtrim(argv[2]),"/") == 0) {
                while (num2 >= s_num2 && num2 < e_num2) {
                    if (num1 / num2 == num3) {
                        mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                    }
                    num2++;
                }
                num3++;
            }

        }
    }

    else if (q_num1 > 0 && q_num3 > 0 && q_num2 == 0){
        while (num3 >= s_num3 && num3 < e_num3) {
            num1 = mx_q_to_num(mx_strtrim(argv[1]));
                if (mx_strcmp(mx_strtrim(argv[2]), "+") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 + num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }
                        num1++;

                    }
                    num3++;

                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0){
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 - num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num3++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 * num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num3++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]),"/") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 / num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num3++;
                }
        }
    }
    else if (q_num1 > 0 && q_num2 > 0 && q_num3 == 0){
        while (num2 >= s_num2 && num2 < e_num2) {
            num1 = mx_q_to_num(mx_strtrim(argv[1]));
                if (mx_strcmp(mx_strtrim(argv[2]), "+") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 + num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }
                        num1++;

                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "-") == 0){
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 - num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]), "*") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 * num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num2++;
                }
                else if (mx_strcmp(mx_strtrim(argv[2]),"/") == 0) {
                    while (num1 >= s_num1 && num1 < e_num1) {
                        if (num1 / num2 == num3) {
                            mx_print_equat(num1, mx_strtrim(argv[2]), num2, num3);
                        }

                        num1++;
                    }
                    num2++;
                }
        }
    }
}
