#include "../inc/calc.h"

int mx_strt_of_q_mrk(char *str) {
    int i = 0;
    int j = 0;
    while (str[j]) {
        if (mx_strcmp(&str[i], "?") == 0)
            i++;
        j++;
    }
    if (i != 0) {
        int count = 1;
        if (i == 0)
            count = 1;
        else {
            for (int j = 0; j < i - 1; j++) {
                count *= 10;
            }
        }
        return count;
    }
    else {
        return 0;
    }
}
