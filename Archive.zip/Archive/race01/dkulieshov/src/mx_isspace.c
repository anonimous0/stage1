#include "../inc/calc.h"

bool mx_isspace(int c) {
    if  (((c >= 9) && (c <= 13)) || (c == 32))
        return 1;
    else
        return 0;
}
