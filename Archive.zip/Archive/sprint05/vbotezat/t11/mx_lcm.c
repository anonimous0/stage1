#include <stdio.h>

int mx_gcd(int a, int b);

int mx_lcm(int a,  int b) {
    if (a < 0)
        a *= -1;
    return a / mx_gcd(a, b) * b;
}

int main() {
    printf("%d\n", mx_lcm(20, 15));
    printf("%d\n", mx_lcm(-20, 15));
    return 0;
}
