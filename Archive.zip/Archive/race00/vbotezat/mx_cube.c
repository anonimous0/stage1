#include <stdio.h>
#include <unistd.h>

void mx_printchar(char c);

void mx_cube(int n) {
    int e_first = n / 2, e_second = 1 + n * 2 + n / 2, e_third = 2 + n * 2 + n / 2;
    for (int i = 0; i < 3 + n + n / 2; i++) {
        if (n <= 1)
            break;
        for (int j = 0; j < (n / 2) + 3 + (n * 2); j++) {

            if (i == 0) {
                if (j <= n / 2)
                    mx_printchar(' ');
                else if (j == (n / 2) + 1)
                    mx_printchar('+');
                else if (j > (n / 2) + 1 && j < (n / 2) + 2 + (n * 2))
                    mx_printchar('-');
                else {
                    mx_printchar('+');
                    mx_printchar('\n');
                }
            }

            else if (i > 0 && i <= n / 2) {
                if (j != e_first && j != e_second && j != e_third)
                    mx_printchar(' ');
                else if (j == e_first || j == e_second)
                    mx_printchar('/');
                else
                    mx_printchar('|');

                }
            else if (i == n / 2 + 1) {
                if (j == 0 )
                    mx_printchar('+');
                else if (j > 0 && j <= n * 2)
                    mx_printchar('-');
                else if (j == n * 2 + 1)
                    mx_printchar('+');
                else if (j >n * 2 + 1 && j < n * 2 + 2 + n / 2)
                    mx_printchar(' ');
                else
                    mx_printchar('|');
                }
            else if (i > (n / 2) + 1 && i < 2 + n + n / 2) {
                if (j == e_first || j == e_second )
                    mx_printchar('|');
                else if (j == e_third && i < n + 1)
                    mx_printchar('|');
                else if (j == e_third && i == n + 1)
                    mx_printchar('+');
                else if (j == e_third && i > n + 1)
                    mx_printchar('/');
                else if (j < e_third && i <= n + 1)
                    mx_printchar(' ');
                else if (j < e_third - 1 && i > n + 1)
                    mx_printchar(' ');

            }
            else if (i == 2 + n + n / 2){
                if (j == e_first || j == e_second)
                    mx_printchar('+');
                else if (j > 0 && j <= n * 2)
                    mx_printchar('-');
                else if (j == e_third)
                    mx_printchar('\n');
            }
        }

        if (i > 0 && i <= n / 2 ) {
            mx_printchar('\n');
            e_first--;
            e_second--;
        }
        else if (i > n / 2 && i <= n + 2){
            mx_printchar('\n');
            if (i == n + 2)
                e_third--;
        }
        else if (i > n + 2 && i <  2 + n + n / 2) {
            e_third--;
            mx_printchar('\n');
        }
    }
}
