#include <stdio.h>
#include <unistd.h>

void mx_printchar(char c);

void mx_pyramid(int n) {
    int e_first = n - 2, e_second = n + 1, e_third = n + 2;
    for (int i = 0; i < n; i++) {
        if (n <= 1 || n % 2 != 0)
            break;
        for (int j = 0; j < n * 2 + 1; j++) {
            if (i == 0) {
                if (j == n - 1)
                    mx_printchar('/');
                else if (j == n){
                    mx_printchar('\\');
                    mx_printchar('\n');
                }
                else if (j < n)
                    mx_printchar(' ');
            }
            else if (i > 0 && i < n / 2) {
                if (j == e_first)
                    mx_printchar('/');
                else if (j == e_second || j == e_third)
                    mx_printchar('\\');
                else if (j < e_third)
                    mx_printchar(' ');
            }
            else if (i >= n / 2 && i < n) {
                if (j == e_first)
                    mx_printchar('/');
                else if (j == e_second)
                    mx_printchar('\\');
                else if (j == e_third)
                    mx_printchar('|');
                else if (j < e_third && i != n - 1)
                    mx_printchar(' ');
                else if ( i == n - 1 )
                    mx_printchar('_');
            }
        }
        if (i > 0 && i < n) {
            e_first--;
            e_second++;
        }
        if (i > 0 && i < n / 2) {
            mx_printchar('\n');
            e_third += 2;
        }
        if (i >= n / 2 && i <= n)
            mx_printchar('\n');
    }
}
