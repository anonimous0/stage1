#include <stdio.h>
#include <stdbool.h>

bool mx_is_prime(int num);

double mx_pow(double n, unsigned int pow);

bool mx_is_mersenne(int n) {
    if (mx_is_prime(mx_pow(2, n) - 1) == true)
        return true;
    else
        return false;
}

int main() {
    printf("%d\n",mx_is_mersenne(3));
    printf("%d\n",mx_is_mersenne(11));
    return 0;
}
