#include <stdio.h>
#include <stdbool.h>

bool mx_is_prime(int num){
    int f = 0;

    if (num < 2)
        return false;

    else {
        for (int i = 2; i <= (num / 2); i++) {
            if (num % i == 0)
                f++;
        }
        if (f == 0)
            return true;
        else
            return false;
    }
}
