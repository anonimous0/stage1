#include <stdio.h>

void mx_ref_pointer(int i, int ******ptr) {
     ******ptr = i;
}
