#include <stdio.h>
#include <stdbool.h>

double mx_pow(double n, unsigned int pow);

bool mx_is_narcissistic(int num) {
    int sum = 0, count = 0;

    if (num < 0)
        return false;
    else {
        while (num % 10 != 0) {
            count++;
            num = num / 10;
        }
        while (num % 10 != 0) {
            sum = sum + mx_pow(num % 10, count);
            num = num / 10;
        }
        if (sum == num)
            return true;
        else
            return false;
    }
}
