#include <stdio.h>
#include <unistd.h>

void mx_printchar(char c);

void mx_hexadecimal(void) {
    for (int i = 30; i<=39; i++)
        mx_printchar(i);
    for (int i = 41; i<=46; i++)
        mx_printchar(i);
    write(1, "\n", 1);
}

