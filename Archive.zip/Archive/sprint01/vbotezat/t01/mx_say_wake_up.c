#include <stdio.h>

void mx_say_wake_up(void) {
    printf("Wake up, NEO \\ (^_^) / ...\nThe Matrix has you ...\n");
}

