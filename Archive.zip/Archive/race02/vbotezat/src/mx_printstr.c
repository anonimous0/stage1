#include "../inc/header.h"

void mx_printstr(const char *s) {
    int count = 0;
    while(s[count]) {
        count++;
    }
    write(1, s, count);
}
