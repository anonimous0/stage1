#include "../inc/header.h"

int **mx_int_matrix (char *res, int *row, int *column) {
    int i;
    int c = 0;
    int r = 0;

    for (i = 0; res[i] != '\0'; ++i) {
        if (res[i] == '\n') {
           ++r;
        }
    }
    c = (i - r) / r;

    int **mat = (int **)malloc(r * sizeof(int*));

    for (int i = 0; i < r; i++) {
        mat[i] = (int*)malloc(c * sizeof(int*));
    }
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            if (i == 0) {
                if (res[j] == '#') {
                    mat[i][j] = -1;
                }
                else if (res[j] == '.') {
                    mat[i][j] = -2;
                }
                else if (res[j] != ',' && res[j] != '\n') {
                    mx_printerr("map error\n");
                    exit(0);
                }
            }
            else {
                if (res[j + i * (c + 1)] == '#') {
                    mat[i][j] = -1;
                }
                else if (res[j + i * (c + 1)] == '.') {
                    mat[i][j] = -2;
                }
                else if (res[j + i * (c + 1)] != ',' && res[j + i * (c + 1)] != '\n') {
                    mx_printerr("map error\n");
                    exit(0);
                }
            }
        }
    }
    *column = c;
    *row = r;
    return mat;
}
