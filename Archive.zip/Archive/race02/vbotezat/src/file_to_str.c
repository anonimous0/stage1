#include "../inc/header.h"

char *mx_file_to_str(const char *filename) {
     int fl = open(filename,O_RDONLY);
     char s[1];
     int n = read(fl , s, sizeof(s));
     int count = 0;

     while(n > 0) {
         if (s[0] == '#' || s[0] == '.' || s[0] == '\n' ){
             ++count;
         }
         n = read (fl, s, sizeof(s));
     }
     close(fl);
     fl = open(filename,O_RDONLY);
     char *res = (char *)malloc(sizeof(char) * count + 1);

     n = read(fl, s, 1);

     for(int i = 0; i < count && n > 0; ++i) {
         if (s[0] == '.' || s[0] == '#' || s[0] == '\n') {
            res[i] = s[0];
            ++i;
          }
          n = read(fl, s, 1);
          --i;
     }
    res[count] = '\0';
    close(fl);
    return res;
}
