echo "Follow the white rabbit."> instructions.txt

