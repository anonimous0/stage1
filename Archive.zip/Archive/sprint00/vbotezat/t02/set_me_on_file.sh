#!/bin/sh
touch fire
chmod = fire
chmod u+r fire
touch -t 191806150000.00 fire

