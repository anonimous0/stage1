grep -iw redpill "$@"
