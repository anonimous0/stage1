
rm -fd "$@" 