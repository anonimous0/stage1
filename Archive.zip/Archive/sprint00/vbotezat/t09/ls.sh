ls -Ahsl "$@" | awk 'NR > 1 {print $10, $6}' 
