#!/bin/sh
man man

