touch git_history.txt
git log --no-decorate --oneline -n 3 --graph > git_history.txt
