touch $1
echo -e "alias ga='git add' \n alias gcmsg=' git commit -m'\n alias gp=' hit push'" >> $1
