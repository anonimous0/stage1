#include <stdio.h>
void mx_arr_rotate(int *arr, int size, int shift) {
    int f = 0;
    int t_arr[size];

    if (shift < 0) {
        f = 1;
        shift *= -1;
    }

    if (shift > size)
        shift = shift % size;

    if (f == 1) {
        shift = size - shift;
    }

    for (int i = 0; i < size; i++)
        t_arr[i] = 0;

    for (int i = 0; i < size; i++) {
        if ((i + shift) < size)
            t_arr[i + shift] = arr[i];
        else
            t_arr[i - (size - shift)] = arr[i];
    }

    for (int i = 0; i < size; i++)
        arr[i] = t_arr[i];
}
