gcc -c mx_atoi.c mx_isspace.c mx_printint.c mx_strcmp.c mx_strlen.c mx_isdigit.c mx_printchar.c mx_printstr.c mx_strcpy.c
ar rc minilibmx.a mx_atoi.o mx_isspace.o mx_printint.o mx_strcmp.o mx_strlen.o mx_isdigit.o mx_printchar.o mx_printstr.o mx_strcpy.o
ranlib minilibmx.a
