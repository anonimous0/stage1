#include <time.h>
#include <stdio.h>

double mx_timer(void(*f)()) {
    double start = clock();
    f();
    double stop = clock();
    if (stop < 0 || start < 0)
        return -1;
    return stop - start;

}
