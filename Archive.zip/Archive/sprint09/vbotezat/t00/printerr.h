#ifndef CHOICE_H
#define CHOICE_H

#include <unisdt.h>
#include <stdio.h>

void mx_printerr(const char *s);

#endif
