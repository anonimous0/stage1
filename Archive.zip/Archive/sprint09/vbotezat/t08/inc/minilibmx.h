#ifndef MINILIBMX_H
#define MINILIBMX_H

#include <unistd.h>
#include <stdbool.h>

int mx_strlen(const char *s);

bool mx_isdigit(int c);

void mx_write_error(int error);

void mx_write_operation(int a, int b);

int mx_atoi(const char *str);

int mx_strcmp(const char *s1, const char *s2);

bool mx_isspace(char c);

void mx_printint(int n);

void mx_printchar(char c);

#endif
