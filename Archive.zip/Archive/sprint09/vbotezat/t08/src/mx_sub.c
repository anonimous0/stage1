#include "../inc/calculator.h"

int mx_sub(int a, int b) {
    return a - b;
}
