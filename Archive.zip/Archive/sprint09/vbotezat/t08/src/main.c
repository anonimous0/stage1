#include "../inc/calculator.h"

int main(int argc, const char *argv[]) {
    if (argc < 1 && argv == NULL)
        write(2, "usage: ./calc [operand1] [operation] [operand2]", 47);
    else if (!mx_isdigit((char)mx_atoi(argv[1])) || !mx_isdigit((char)mx_atoi(argv[3])))
        mx_write_error(0);
    else if (mx_strcmp(argv[2],"+") != 0 || mx_strcmp(argv[2],"-") != 0 || mx_strcmp(argv[2],"/") != 0 || mx_strcmp(argv[2],"%") != 0 || mx_strcmp(argv[2],"*") != 0)
        mx_write_error(1);
    else if (argv[3] == 0)
        mx_write_error(2);

    /*if (argc < 1) //!!убрать, это тут чтоб не выдавало ошибку
        return -1;
        mx_write_operation(mx_atoi(argv[1]), mx_atoi(argv[3]));*/

    return 0;
}
