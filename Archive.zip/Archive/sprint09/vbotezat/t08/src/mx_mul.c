#include "../inc/calculator.h"

int mx_mul(int a, int b) {
    return a * b;
}
