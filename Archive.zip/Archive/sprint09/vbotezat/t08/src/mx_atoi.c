#include "../inc/calculator.h"

int mx_atoi(const char *str) {
    int res = 0;
    int negative = 0;

    for (int i = 0; str[i]; i++) {
        for (int j = 48; j <= 57; j++) {
            if((int)str[i] == 45) {
                negative = 1;
                continue;
            }
            if((int)str[i] == j) {
                res += (j - 48);
                if(str[i + 1])
                    res *= 10;
            }
            if(mx_isspace(str[i]))
                continue;
            if(!mx_isdigit(str[i])) {
                if(negative == 1)
                    res *= -1;
                return (res / 10);
            }
        }
    }
    if(negative == 1) {
        res *= -1;
    }
    return res;
}
