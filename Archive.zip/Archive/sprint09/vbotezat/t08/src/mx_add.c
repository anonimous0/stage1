#include "../inc/calculator.h"

int mx_add(int a, int b) {
    return a + b;
}
