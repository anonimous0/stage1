#include "../inc/calculator.h"

void mx_write_error(int error) {
    char *s1 = "error: invalid number";
    char *s2 = "error: invalid operation";
    char *s3 = "error: division by zero";

    if (error == 0)
        write(2, s1, mx_strlen(s1));
    if (error == 1)
        write(2, s2, mx_strlen(s2));
    if (error == 2)
        write(2, s3, mx_strlen(s3));
}
