#include "../inc/calculator.h"

void mx_write_operation(int a, int b) {
    int result;
    /*t_operation oper;
    oper.op = op;
    enum e_operation operation;

    if (mx_strcmp(&op, "+") == 0) {
        operation = 1;
        oper.f = *mx_add;
    }
    if (mx_strcmp(&op, "-") == 0) {
        operation = 0;
        oper.f = *mx_sub;
    }
    if (mx_strcmp(&op, "*") == 0) {
        operation = 2;
        oper.f = *mx_mul;
    }
    if (mx_strcmp(&op, "/") == 0) {
        operation = 3;
        oper.f = *mx_div;
    }
    if (mx_strcmp(&op, "%") == 0) {
        operation = 4;
        oper.f = *mx_mod;
    }*/
    result = mx_add(a, b);
    mx_printint(result);
}
