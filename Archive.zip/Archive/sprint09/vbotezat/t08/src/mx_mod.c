#include "../inc/calculator.h"

int mx_mod(int a, int b) {
    return a % b;
}
