#include "../inc/calculator.h"

int mx_div(int a, int b) {
    return a / b;
}
