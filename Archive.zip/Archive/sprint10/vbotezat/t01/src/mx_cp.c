#include "../inc/header.h"

int main(int argc, char const *argv[]) {
    char buff;
    int fl1 = 0;
    int fl2 = 0;

    if (argc == 3) {
        fl1 = open(argv[1], O_RDONLY);


        if (fl1 == -1) {
            mx_write_error("mx_cp: ");
            mx_write_error(argv[1]);
            mx_write_error(": ");
            mx_write_error((strerror(errno)));
            mx_write_error("\n");
        }
        else {
            fl2 = open(argv[2], O_CREAT| O_EXCL | O_WRONLY, S_IWUSR | S_IRUSR);
            while(read(fl1, &buff, 1)) {
                write(fl2, &buff, 1);
            }
        }
    }
    else {
        mx_write_error("usage: ./mx_cp [source_file] [destination_file]\n");
    }
    close(fl1);
    close(fl2);
    exit(0);
}
