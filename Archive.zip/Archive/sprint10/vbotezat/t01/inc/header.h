#ifndef HEADER_H
#define HEADER_H

#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <errno.h>

int mx_strlen(const char *s);

void mx_write_error(const char *str);

int main(int argc, char const *argv[]);

#endif
