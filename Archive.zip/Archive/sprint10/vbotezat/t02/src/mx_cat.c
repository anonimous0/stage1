#include "../inc/header.h"

int main(int argc, char const *argv[]) {
    char s[1];

    if (argc == 2) {
        int fl = open(argv[1], O_RDONLY);

        if (fl == -1) {
            mx_write_error("mx_cp: ");
            mx_write_error(argv[1]);
            mx_write_error(": ");
            mx_write_error((strerror(errno)));
            mx_write_error("\n");
        }
        else {
            while(read(fl, s, 1)) {
                write(1, s, 1);
            }
        }
        close(fl);
    }
    else if (argc == 1) {
        while(read(0, s, 1 > 0) && s[0] != '\n')
            write(0, s, 1);
        write(1, "\n", 1);
    }
    return 0;
    exit(0);
}
