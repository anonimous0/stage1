#include "../inc/header.h"

void mx_write_error(const char *str) {
    write(2, str, mx_strlen(str));
}
