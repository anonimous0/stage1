#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int mx_strlen(const char *s);
void mx_write_error(const char *str);
int main(int argc, char const *argv[]);

#endif
