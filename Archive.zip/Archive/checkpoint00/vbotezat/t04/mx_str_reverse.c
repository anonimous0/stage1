#include <stdio.h>

int mx_strlen(char *s) {
    int count = 0;
    while(s[count])
        count++;
    return count;
}

void mx_swap_char(char *s1, char *s2){
    char f = *s1;
    *s1 = *s2;
    *s2 = f;
}

void mx_str_reverse(char *s) {
    for (int i = 0; i < mx_strlen(s) / 2; i++)
        mx_swap_char(&s[i], &s[mx_strlen(s) - i - 1]);
}
