#include <stdio.h>
#include <unistd.h>

void mx_only_printable(void) {
    char n = 10;
    for (char i = 126; i >= 32; i--) {
        write(1, &i, 1);
        write(1, &n, 1);
    }
}
