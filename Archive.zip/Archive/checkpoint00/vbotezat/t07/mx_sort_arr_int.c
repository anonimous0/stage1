#include <stdio.h>

void mx_sort_arr_int(int *arr, int size) {
    for (int i = 0; i < size - 1; i++){
        int f = 0;
        for (int j = 0; j < size - i - 1; j++) {
            if (arr[j] > arr[j + 1]){
                f = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = f;
            }
        }
    }
}
