#include <stdio.h>

int mx_popular_int(const int *arr, int size) {
    int max_count = 1, n = -1;
    for (int i = 0; i < size; i++) {
        int count = 0;
        for (int j = i; j < size; j++)
            if (arr[i] == arr [j])
                count++;
        if (max_count < count) {
            max_count = count;
            n = i;
        }
    }
    return arr[n];
}

int main() {
    int arr[] = {4,4,4,5,5,5,3};
    printf("%d\n", mx_popular_int(arr,7));
    return 0;
}
