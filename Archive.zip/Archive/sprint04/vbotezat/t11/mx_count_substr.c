#include <stdio.h>
#include <unistd.h>

char *mx_strchr(const char *s, int c);

int mx_strlen(const char *s);

int mx_strncmp(const char *s1, const char *s2, int n);

char *mx_strstr(const char *s1, const char *s2);

int mx_count_substr(const char *str, const char *sub) {
    int i = 0;

    if (sub == NULL || str == NULL)
        return 0;
    else if (mx_strlen(str) >= mx_strlen(sub)){
        while(*str) {
            if (!mx_strncmp((char *)str, (char *)sub, mx_strlen(sub)))
                i++;
            str++;
        }

    }
    return i;
}

int main () {
    const char s1[] = "yo, yo, yo Neo";
    const char s2[] = "yo";
    printf("%d\n", mx_count_substr(s1, s2));
    return 0;
}
