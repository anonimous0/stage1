#include <stdio.h>

int mx_mid(int a, int b, int c) {
    if ((c < a) && (a < b) || (c > a) && (a > b))
        return a;
    else if ((c < b) && (b < a) || (c > b) && (b > a))
        return b;
    else
        return c;
}

