#include <stdlib.h>
#include <stdio.h>

int *mx_copy_int_arr(const int *src, int size) {
    int i = 0;

    if (size <= 0)
        return NULL;

    int *arr_i = (int *)malloc(size);

    while (i < size) {
        arr_i[i] = src[i];
        i++;
    }
    return arr_i;
}
