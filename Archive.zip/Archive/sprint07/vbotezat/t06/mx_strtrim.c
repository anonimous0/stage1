#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

bool mx_isspace(int c);

char *mx_strcpy(char *dst, const char *src);

void mx_strdel(char **str);

int mx_strlen(const char *s);

char *mx_strnew(const int size);

char *mx_strtrim(const char *str) {
    char *str_upd = mx_strnew(mx_strlen(str));
    int f = 0;
    int i = 0;
    int j = mx_strlen(str) - 1;

    if (!str)
        return NULL;
    else {
            while(mx_isspace(str[i]) == 1) {
                i++;
                f = 1;
            }

            while(mx_isspace(str[j]) == 1) {
                j--;
                f = 1;
            }

            int k = 0;
            while (i <= j) {
                str_upd[k] = str[i];
                i++;
                k++;
            }
            if (f == 0)
                return NULL;
            else
                return str_upd;
    }
}
