#include <stdio.h>
#include <stdlib.h>

int mx_strlen(const char *s);

char *mx_strcat(char *restrict s1, const char *restrict s2);

char *mx_strcpy(char *dst, const char *src);

char *mx_strnew(const int size);

char *mx_strdup(const char *str);

char *mx_strjoin(char const *s1, char const *s2);

void mx_strdel(char **str);

char *mx_concat_words(char **words) {
    char *phr;
    int count = 0;

    if (!words)
        return NULL;

    else {
        while (words[count])
            count++;

        for (int i = 0; i < count; i++) {
            if (i == 0)
                phr = mx_strjoin(phr, words[i]);

            else {
                phr = mx_strjoin(phr, " ");
                phr = mx_strjoin(phr, words[i]);
            }
        }

        mx_strdel(words);
        return str;
    }
}
