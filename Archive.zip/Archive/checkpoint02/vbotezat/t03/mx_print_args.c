#include <stdio.h>
#include <unistd.h>

int mx_strlen(const char *s) {
    int i = 0;

    while (s[i])
        i++;
    return i;
}

int main(int argc, char const *argv[]) {
    char c = '\n';
    if (argc == 0)
        return 0;

    else {
        for (int i = 0; i < argc; i++) {
            write(1, argv[i],mx_strlen(argv[i]));
            write(1, &c, 1);
        }
    }
    return 0;
}
