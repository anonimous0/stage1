#include <stdio.h>
#include <stdlib.h>

char *mx_strdup(const char *str) {
    int size = 0;
    int j = 0;

    while (str[size])
        size++;
    if (size < 0)
        return NULL;

    char *str_cop = (char *)malloc(size + 1);

    while (str[j]) {
        str_cop[j] = str[j];
        j++;
    }
    str_cop[j] = '\0';
    return str_cop;
}
