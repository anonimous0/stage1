#include <stdio.h>

int mx_atoi(const char *str) {
    int i = 0;
    while(str[i]) {
        if (str[i] == 48)
            return 0;
        if (str[i] == 49)
            return 1;
        if (str[i] == 50)
            return 2;
        if (str[i] == 51)
            return 3;
        if (str[i] == 52)
            return 4;
        if (str[i] == 53)
            return 5;
        if (str[i] == 54)
            return 6;
        if (str[i] == 55)
            return 7;
        if (str[i] == 56)
            return 8;
        if (str[i] == 57)
            return 9;
        i++;
    }
    return 0;
}
