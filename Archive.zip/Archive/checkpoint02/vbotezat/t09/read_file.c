#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>

int mx_strlen(const char *s) {
    int i = 0;

    while (s[i])
        i++;
    return i;
}
void mx_write_error(const char *str) {
    write(2, str, mx_strlen(str));
}
int main(int argc, char const *argv[]) {
    char buff;
    int fp = 0;

    if (argc != 2) {
        mx_write_error("usage: ./read_file [file_path]");
        return 0;
    }
    else if ((fp = open(argv[1], O_RDONLY)) == -1)
    {
        mx_write_error("error\n");
        return 0;
    }
    else {
        int fp = open(argv[1], O_RDONLY);
        while (read(fp, &buff, 1))
            write(1, &buff, 1);
        return 0;
    }
    close(fp);
}
