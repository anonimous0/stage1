#include "list.h"
int mx_list_size(t_list *list) {
int count = 0;

if(list)
{
    while(list != NULL)
    {
        n++;
        list = list->next;
    }
}
return n;
}
