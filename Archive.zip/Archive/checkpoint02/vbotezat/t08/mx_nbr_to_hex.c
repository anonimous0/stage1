#include <stdio.h>
#include <stdlib.h>

char *mx_strnew(const int size) {
    int i = 0;

    if (size < 0)
        return NULL;

    char *str = (char *)malloc(size + 1);

    while (i < size) {
        str[i] = '\0';
        i++;
    }
    str[i] = '\0';
    return str;
}

char *mx_nbr_to_hex(unsigned long nbr) {

    unsigned long i = 0;
    unsigned long nbr_c = nbr;
    while (nbr_c / 16 >= 1) {
        nbr_c /= 16;
        i++;
    }
    if (nbr == 0)
        return 0;
    char *hex_str = mx_strnew(i + 4);

    while(nbr != 0) {
        if (nbr % 16 < 10)
            hex_str[i] = nbr % 16 + '0';
        else if(nbr % 16 == 10)
            hex_str[i] = 'a';
        else if(nbr % 16 == 11)
            hex_str[i] = 'b';
        else if(nbr % 16 == 12)
            hex_str[i] = 'c';
        else if(nbr % 16 == 13)
            hex_str[i] = 'd';
        else if(nbr % 16 == 14)
            hex_str[i] = 'e';
        else if(nbr % 16 == 15)
            hex_str[i] = 'f';
        i--;
        nbr /= 16;
    }
    return hex_str;
}
