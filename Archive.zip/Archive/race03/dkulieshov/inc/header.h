#ifndef HEADER
#define HEADER

#include <ncurses.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <locale.h>

#define SHORT_DROPLET
#ifdef SHORT_DROPLET

struct droplet{
    unsigned short length, col;
    short row;   //signed so droplets can start above screen
    unsigned short frames_per_row;
};

#else //SHORT_DROPLET
struct droplet{
    unsigned int length, col;
    int row;    //signed so droplets can start above screen
    unsigned int frames_per_row;
};

#endif //SHORT_DROPLET

int mx_init_droplets();
void mx_cleanup();
int mx_draw_rain();
int mx_draw_droplet(struct droplet *drop);
int mx_gen_droplet_props(struct droplet *drop);
int mx_droplets_realloc();
void mx_printerr(const char *s);
int mx_strlen(const char *s);
void mx_matrix_rain();
void mx_print_lines();
char *mx_rand_japan();
void mx_print_massage(char *str, int row, int col);

unsigned int refresh_rate;
char multicolor_trail;
char velocity;
char primary_color;
char secondary_color;

static const char max_char = 126, min_char = 33;
static unsigned int max_row, max_col;
static unsigned int num_of_droplets;
static struct droplet *droplets;

#endif
