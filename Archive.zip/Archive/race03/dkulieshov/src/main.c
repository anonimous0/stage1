#include "../inc/header.h"

void mx_print_massage(char *str, int row, int col) {
    for (int i = 0; str[i] != '\0'; i++)  {
        init_pair (1, COLOR_GREEN, COLOR_BLACK);
        attron (COLOR_PAIR(1));
        mvaddch(row, col, str[i] | A_BOLD);
        col++;
        refresh();
        usleep(200000);
    }
}


void mx_print_lines() {
    curs_set(0);
    char *str;
    int col = 2;
    int row = 2;

    str = "Wake up , Neo..\0";
    mx_print_massage(str, row, col);
    usleep(1500000);
    erase();

    str = "The Matrix has you..\0";
    mx_print_massage(str, row, col);
    usleep(1500000);
    erase();

    str = "Follow the white rabbit";
    mx_print_massage(str, row, col);
    usleep(1500000);
    erase();

    str = "Knock, knock, Neo\0";
    mx_print_massage(str, row, col);
    usleep(1500000);
    erase();
}

int main(int argc, char *argv[]) {
    setlocale(LC_ALL,"ja_JP");
    if(argc > 1 || argv[1]){
        mx_printerr("usage ./matrix_rain");
        return 0;
    }
    initscr();
    start_color();
    mx_print_lines();
    mx_matrix_rain();
    endwin();
    return 0;
}
