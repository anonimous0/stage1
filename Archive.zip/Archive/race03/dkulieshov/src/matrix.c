#include "../inc/header.h"


void mx_matrix_rain() {
    //initscr();
    curs_set(0);
    keypad(stdscr, TRUE);
    noecho();
    cbreak();
    nodelay(stdscr, TRUE);
    mx_init_droplets();
    atexit(mx_cleanup);

    if(!has_colors()){
        printf("You have no colors :(\n");
        exit(0);
    }
    //start_color();
    //use_default_colors();
    init_pair(1, COLOR_GREEN, COLOR_BLACK);
    init_pair(2, COLOR_RED, COLOR_BLACK);
    init_pair(3, COLOR_BLACK, COLOR_BLACK);
    init_pair(4, COLOR_YELLOW, COLOR_BLACK);
    init_pair(5, COLOR_BLUE, COLOR_BLACK);
    init_pair(6, COLOR_MAGENTA, COLOR_BLACK);
    init_pair(7, COLOR_CYAN, COLOR_BLACK);
    init_pair(8, COLOR_WHITE, COLOR_BLACK);

    attron(COLOR_PAIR(1));
    struct timespec ts;
    ts.tv_sec = 20/10000;
    ts.tv_nsec = (20 % 1000) * 1000000;

    refresh_rate = 7;
    multicolor_trail = 0;
    velocity = 1;
    primary_color = 1;
    secondary_color = 7;

    while(1){
        mx_draw_rain();
        usleep(20000);
        switch(getch()){
            case 'q':
                exit(0);
                break;
            case 'c':
                if(multicolor_trail){
                    multicolor_trail = 0;
                }
                else{
                    multicolor_trail = 1;
                }
                break;
            case 'v':
                velocity *= 0.5;
                break;
            case '1':
                primary_color = 1;
                break;
            case '2':
                primary_color = 2;
                break;
            case '3':
                primary_color = 3;
                break;
            case '4':
                primary_color = 4;
                break;
            case '5':
                primary_color = 5;
                break;
            case '6':
                primary_color = 6;
                break;
            case '7':
                primary_color = 7;
                break;
            case '8':
                primary_color = 8;
                break;
            case KEY_F(1):
                secondary_color = 1;
                break;
            case KEY_F(2):
                secondary_color = 2;
                break;
            case KEY_F(3):
                secondary_color = 3;
                break;
            case KEY_F(4):
                secondary_color = 4;
                break;
            case KEY_F(5):
                secondary_color = 5;
                break;
            case KEY_F(6):
                secondary_color = 6;
                break;
            case KEY_F(7):
                secondary_color = 7;
                break;
            case KEY_F(8):
                secondary_color = 8;
                break;
            case KEY_DOWN:
                if(refresh_rate < 20){
                    refresh_rate++;
                }
                break;
            case KEY_UP:
                if(refresh_rate > 1){
                    refresh_rate--;
                }
                break;
            case 't'://test
                printf("%u", refresh_rate);
                break;
            default:
                break;
        }
    }
    //endwin();
    refresh();
    printf("Reached end of main, this should never happen\n");
}
