#include <unistd.h>

int mx_strlen(const char *s) {
    int i = 0;

    while (s[i])
        i++;
    return i;
}

void mx_printint(int num) {
    if (num < 0) {
        char a = '-';
        write(1, &a, 1);
        num *=-1;
    }
    if (num > 9)
        mx_printint(num / 10);
    char b = num % 10 + 48;
    write(1, &b, 1);
}

int main(int argc, char const *argv[]) {
    write(1, argv[0], mx_strlen(argv[0]));
    char n = '\n';
    write(1, &n, 1);
    mx_printint(argc);
    write(1, &n, 1);
    return 0;
}
